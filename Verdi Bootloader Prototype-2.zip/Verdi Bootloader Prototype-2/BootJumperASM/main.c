#include "stm32l476xx.h"
#include "mylibrary.h"
#include "SysClock.h"
#include <stdio.h>

/* MAINPROG must be set to the beginning of the main program vector table	*/
/* This has only been tested for code in Flash Bank 1 of STM32L476VGTx (up to 512K)				*/

#define MAINPROG 0x08004000
#define VTOR_NEW (MAINPROG - 0x08000000)

UART_HandleTypeDef huart2;
DMA_HandleTypeDef hdma_usart2_tx;
uint8_t r_update[16000];
uint8_t temp[5600]; //temp buffer for transfer to UART. up-to 43 chars per line in .hex (data itself is 32, rest is other stuff). Transferring one line at a time!
uint8_t mainprog[8];
int temp_int;
uint64_t hex_data_array[512]; //each 32 bit line of data will take up 2 spaces. Each space holds 8 bytes
uint32_t MAIN_PROG[2];
uint32_t hex_address;
uint32_t hex_addresses[256];
uint32_t address;
uint8_t start = 0;
int write_error = 0;
uint8_t start_rec = 1;
int data_line[43];
uint8_t next = 0;
uint8_t data_page[5600];
char *rfilename = "sapp.hex";
uint8_t version = 0;
uint64_t version_64;
uint32_t server_version_address = 0x08003000;
uint32_t server_version_read;
int i = 0;
int r = 0;
int r_index = 0;
int pg_index = 0;
uint8_t ACK = 1;
int count = 0;
int data_len = 0;
uint8_t startup_btl = 0; //has bootloader from end device started?
extern HAL_StatusTypeDef HAL_FLASH_Program(uint32_t TypeProgram, uint32_t Address, uint64_t Data);
extern HAL_StatusTypeDef HAL_FLASHEx_Erase(FLASH_EraseInitTypeDef *pEraseInit, uint32_t *PageError);
extern HAL_StatusTypeDef HAL_FLASH_Unlock(void);
extern HAL_StatusTypeDef HAL_FLASH_Lock(void);
extern HAL_StatusTypeDef HAL_UART_Receive(UART_HandleTypeDef *huart, uint8_t *pData, uint16_t Size, uint32_t Timeout);
extern HAL_StatusTypeDef HAL_UART_Transmit(UART_HandleTypeDef *huart, uint8_t *pData, uint16_t Size, uint32_t Timeout);
extern HAL_StatusTypeDef HAL_UART_Init(UART_HandleTypeDef *huart);
extern HAL_StatusTypeDef HAL_RCC_OscConfig(RCC_OscInitTypeDef  *RCC_OscInitStruct);
extern HAL_StatusTypeDef HAL_Init(void);
extern HAL_StatusTypeDef HAL_UART_Transmit_IT(UART_HandleTypeDef *huart, uint8_t *pData, uint16_t Size);
extern HAL_StatusTypeDef HAL_UART_Receive_IT(UART_HandleTypeDef *huart, uint8_t *pData, uint16_t Size);
extern void Error_Handler(void);
extern void HAL_PWR_EnableBkUpAccess(void);
extern void HAL_GPIO_TogglePin(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);
extern void HAL_GPIO_WritePin(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin, GPIO_PinState PinState);
extern void HAL_GPIO_Init(GPIO_TypeDef  *GPIOx, GPIO_InitTypeDef *GPIO_Init);
extern __weak void HAL_Delay(uint32_t Delay);
extern void HAL_NVIC_SetPriority(IRQn_Type IRQn, uint32_t PreemptPriority, uint32_t SubPriority);
extern void HAL_NVIC_EnableIRQ(IRQn_Type IRQn);
extern HAL_StatusTypeDef HAL_RCC_ClockConfig(RCC_ClkInitTypeDef  *RCC_ClkInitStruct, uint32_t FLatency);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_DMA_Init(void);

struct HexIntel {

    size_t m_len;
    unsigned char m_addr[8];
    unsigned char m_data[32];
    unsigned char m_checkSum;
    _Bool m_endOfFile;
    _Bool m_success; // Only set true after checking the EOF, the checksums etc.
} Hex_Intel, *Hex;


enum HEX_INTEL_TYPE {
    DATA = 0, HEX_EOF = 1, EXTENDED_SEGMENT_ADDRESS = 2, START_SEGMENT_ADDRESS = 3,
    EXTENDED_LINEAR_ADDRESS = 4, START_LINEAR_ADDRESS = 5
};

enum HEX_INTEL_RECORD {
    LEN_MSB = 0, LEN_LSB = 1, ADDR_MSB = 2, ADDR_MSB2 = 3, ADDR_LSB2 = 4, ADDR_LSB = 5,
    TYPE_MSB = 6, TYPE_LSB = 7, DATA_START = 8
};

unsigned char hexCharToInt(uint8_t c)
{
    const unsigned char ERROR = 16;
    const int asciiNumberBetweenDigitAndAlpha = 7; // In ASCII, 7 ponctuations marks separate digits from uppercase alphabetical character
    if (c > '/' && c < ':') // In ASCII, '0' is after '/' and ':' after '9'. first run should go here
		{
        c = c - '0'; // In ASCII '0' = 48; '1' = 49..
				//temp_int = c; //was temp[j] = c;
				return c;
		}
    else if (c > '@' && c < 'G') // In ASCII, 'A' is after '@'
		{
        c = c - '0' - asciiNumberBetweenDigitAndAlpha;
				//temp_int = c;
				return c;
		}
		else if (c == 58 || c == 10 || c == 13)
		{
			return c;
		}
    else
    {
        //fprintf(stderr, "Not hexadecimal character, can't be parsed into a int.\n");
        return ERROR;
    }
}

static uint32_t GetPage(uint32_t Address)
{
  for (int indx=0; indx<128; indx++)
  {
	  if((Address < (0x08000000 + (FLASH_PAGE_SIZE *(indx+1))) ) && (Address >= (0x08000000 + FLASH_PAGE_SIZE*indx)))
	  {
		  return (0x08000000 + FLASH_PAGE_SIZE*indx);
	  }
  }

  return 0;
}

uint32_t Flash_Write (uint32_t StartPageAddress, uint64_t *Data, uint16_t numberofwords) //Final page does not write correctly.
{

	static FLASH_EraseInitTypeDef EraseInitStruct;
	uint32_t PAGEError;
	int sofar=0;

	  /* Unlock the Flash to enable the flash control register access *************/
	   	HAL_FLASH_Unlock();
			//WRITE_REG(FLASH->KEYR, 0x45670123);
			//WRITE_REG(FLASH->KEYR, 0xCDEF89AB);

	   /* Erase the user Flash area*/

	  uint32_t StartPage = GetPage(StartPageAddress);
	  uint32_t EndPageAdress = StartPageAddress + numberofwords*4;
	  uint32_t EndPage = GetPage(EndPageAdress);

	   /* Fill EraseInit structure*/
	   EraseInitStruct.TypeErase   = FLASH_TYPEERASE_PAGES;
	   EraseInitStruct.Page = StartPage;
	   EraseInitStruct.NbPages     = ((EndPage - StartPage)/FLASH_PAGE_SIZE) +1; //no errors yet...

	   if (HAL_FLASHEx_Erase(&EraseInitStruct, &PAGEError) != HAL_OK)
	   {
	     /*Error occurred while page erase.*/
			write_error = 1;
		  return HAL_FLASH_GetError (); //getting error A0, which means OPERR is set in FLASH_SR. (meaning unsuccessful erase in this case). How did this get set? Timeout?
	   }

	   /* Program the user Flash area word by word*/

	   while (sofar<numberofwords)
	   {
	     if (HAL_FLASH_Program(FLASH_TYPEPROGRAM_DOUBLEWORD, StartPageAddress, Data[sofar]) == HAL_OK)
	     {
	    	 StartPageAddress += 8;  // use StartPageAddress += 2 for half word and 8 for double word
	    	 sofar++;
	     }
	     else
	     {
	       /* Error occurred while writing data in Flash memory*/
				 write_error = 1;
	    	 return HAL_FLASH_GetError (); //getting error A8. Look into this ASAP tomorrow morning.
	     }
	   }

	   /* Lock the Flash to disable the flash control register access (recommended
	      to protect the FLASH memory against possible unwanted operation) *********/
	   SET_BIT(FLASH->CR, FLASH_CR_LOCK);
		 write_error = 0;
	   return 0;
}


void Flash_Read_Data (uint32_t StartPageAddress, uint32_t *RxBuf, uint16_t numberofwords)
{
	while (1)
	{

		*RxBuf = *(__IO uint32_t *)StartPageAddress;
		StartPageAddress += 4;
		RxBuf++;
		if (!(numberofwords--)) break;
	}
}

static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

bool updateRequested() { //Checks flags to see if update is needed.
	//return false;
	while (version == 0) //Waiting to receive version number from host...
	{
		HAL_UART_Receive (&huart2, &version, sizeof(version), 100);
		HAL_GPIO_TogglePin (LD_R_GPIO_Port, LD_R_Pin);
	}
	if (Hex->m_success != 0) //If pages still need flashing...
	{
		return false;
	}
	if (version != server_version_read) //if server_version_read (Flash/EEPROM) is different than version received
	{
		HAL_GPIO_WritePin (LD_R_GPIO_Port, LD_R_Pin, GPIO_PIN_RESET);
		HAL_UART_Transmit (&huart2, &ACK, 1, 1000);
		return true;
	}
	else if (version == server_version_read) //if versions are the same, then just jump to main
	{
		return false;
	}
	return 0;
}



/* This function will take a pointer to the main program vector table */
/* It will load the stack pointer from that address; load the new PC from the address + 4 */
/* then jump to that address */

__ASM void jumpToMain(uint32_t x) { //Jumps to main
	ldr		sp,[r0]
	ldr		pc, [r0,#4]	
}
int main(void)
{
	HAL_Init();
	System_Clock_Init();
	MX_GPIO_Init();
	MX_DMA_Init();
	MX_USART2_UART_Init();
	Flash_Read_Data(server_version_address, &server_version_read, 1); //Stores a byte of data in flash (version number). Replace with EEPROM.
	int first = 1;
	while (1)
	{
		if (updateRequested()) 
		{
			Hex = &Hex_Intel;
			double page_index = (double)sizeof(r_update)/(double)sizeof(temp);
			int j_index = sizeof(r_update)/page_index;
			while (Hex->m_success != 1)
			{
				while (start != 1) /*reads UART data*/
				{
					HAL_UART_Receive (&huart2, &start, sizeof(start), 1000);
					HAL_Delay (100);
					HAL_GPIO_TogglePin (LD_R_GPIO_Port, LD_R_Pin);
				}
				if (first == 1)
				{
					HAL_GPIO_TogglePin (LD_G_GPIO_Port, LD_G_Pin);
					HAL_UART_Transmit(&huart2, &start_rec, sizeof(start_rec), 100);
					HAL_UART_Receive (&huart2, r_update, 16000, 5000);
				}
				HAL_GPIO_WritePin (LD_R_GPIO_Port, LD_R_Pin, GPIO_PIN_RESET);
				count = 0;
				pg_index = 0;
				for (int j = 0; j < j_index; j++) //for each byte on the page. Every 5600 bytes, stop. This function parses the data from r_update into temp and data_page
				{
					Hex->m_len = j;
					temp[j] = 0;
					if (r_update[r_index] == 58)
					{
						r_index++;
					}
					int ind_next = r_index + 1;
					temp[j] = (hexCharToInt(r_update[r_index]) << 4) + (hexCharToInt(r_update[ind_next]));
					data_page[pg_index] = temp[j];
					if (data_page[pg_index] == 255 && data_page[pg_index-1] == 1 && data_page[pg_index-2] == 0 && data_page[pg_index-3] == 0 && data_page[pg_index-4] == 0)
					{
						for (int i = pg_index + 1; i < j_index; i++)
						{
							data_page[i] = 0;
						}
						break;
					}
					if (temp[j] == 16)
					{
						if (temp[j-1] == 218)
						{
							count++;
						}
					}
					pg_index++;
					r_index += 2;
					if (count == 255) //Once we reach 256 lines of data, we have a page.
					{
						r_index -= 2;
						for (int i = pg_index - 1; i < 5600; i++)
						{
							data_page[i] = 0;
						}
						break;
					}
				}
				int rec = 3;
				int srch = rec + 1;
				int data_index = 0; //up to 512
				int r = 0;
				int flash_amt = 0;
				while (data_index < 512 && r < 255) //Parsing each line for records and acting accordingly
				{
					while (srch < 5600)
					{
						if (data_page[rec] == 0) //copy data to 64 bit array
						{
							for (int j = 0; j < data_page[rec-3]; j++)
							{
								data_len = j;
								memcpy (&Hex->m_data[j], &data_page[srch], sizeof(data_page[srch])); 
								srch++; //we get to the end of data on line 245
							}
							memcpy (&hex_data_array[data_index], &Hex->m_data, sizeof(Hex->m_data));
							rec += data_len + 6;
							srch+= 6;
							data_index += 2;
							flash_amt += 2;
						}
						else if (data_page[rec] == 4) //copy address
						{
							Hex->m_addr[3] = data_page[4];
							Hex->m_addr[2] = data_page[5];
							rec += 7;
							srch += 8;
						}
						else if (data_page[rec] == 5) //copy another address
						{
							mainprog[3] = data_page[rec + 1];
							mainprog[2] = data_page[rec + 2];
							mainprog[1] = data_page[rec + 3];
							mainprog[0] = data_page[rec + 4];
							memcpy (&MAIN_PROG, &mainprog, sizeof(mainprog));
							rec += 9;
						}
						else if(data_page[rec] == 1) //end of file
						{
							flash_amt = data_index - 1;
							for (int i = data_index - 1; i < 512; i++)
							{
								hex_data_array[i] = 0;
							}
							Hex->m_endOfFile = 1;
							break;
						}
						rec++;
					}
					data_index = 512;
					for (int i = 0; i < 5600; i++) //copying addresses and data into final buffers. 32 bits and 64 bits respectively
					{
						if (data_page[i] == 218) //copy addresses to 32 bit array
						{
							if (data_page[i+1] == 16)
							{
								memcpy (&Hex->m_addr[1], &data_page[i + 2], sizeof(data_page[i + 2]));
								memcpy (&Hex->m_addr[0], &data_page[i + 3], sizeof(data_page[i + 3]));
								memcpy (&hex_addresses[r], &Hex->m_addr, sizeof(hex_addresses[r]));
								r++; 
							}
						}
					}
				}
				if (first == 0)
				{
					address = hex_addresses[0] - 16; //change to first address of current array minus 1. View the address variable in debug to see what I mean.
				}
				else if (first == 1)
				{
					address = 0x08004000;
					first = 0; //no longer first page.
				}
				Flash_Write(address, hex_data_array, flash_amt); //Writes page to flash
				if (Hex->m_endOfFile != 0) //If we've reached the end of the file
				{
					Hex->m_success = !Hex->m_success; //Success! Poll updateRequested, reboot, and jump into new code.
					updateRequested();
				}
				else if (Hex->m_endOfFile != 1) //Otherwise, just keep going.
				{
					continue;
				}
			}
			memcpy (&version_64, &version, sizeof (version_64));
			Flash_Write(server_version_address, &version_64, sizeof (version_64)); //Write new version number to flash. Replace this with EEPROM at some point.
			break;
		}
		else //if updateRequested is false...
		{
			HAL_GPIO_WritePin (LD_R_GPIO_Port, LD_R_Pin, GPIO_PIN_RESET);
			SCB->VTOR = (uint32_t) VTOR_NEW;	
		/* Jump to the main program */
			jumpToMain(MAINPROG);
			break;
		}
	}
}

static void MX_GPIO_Init(void) //EEPROM still needs to be implemented.
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, LD_R_Pin|M3V3_REG_ON_Pin, GPIO_PIN_RESET); //gpioB

  /*Configure GPIO pin : LD_R_Pin */
  GPIO_InitStruct.Pin = LD_R_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(LD_R_GPIO_Port, &GPIO_InitStruct); //gpioB

  /*Configure GPIO pin : LD_G_Pin */
  GPIO_InitStruct.Pin = LD_G_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(LD_G_GPIO_Port, &GPIO_InitStruct); //gpioE

  /*Configure GPIO pins : I2C1_SCL_Pin I2C1_SDA_Pin */
  GPIO_InitStruct.Pin = I2C1_SCL_Pin|I2C1_SDA_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF4_I2C1;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct); //gpioB

}

static void MX_DMA_Init(void) //This might not be necessary.
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel7_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel7_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel7_IRQn);

}

