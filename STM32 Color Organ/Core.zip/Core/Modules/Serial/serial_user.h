// serial_user.h

#ifndef _SERIAL_USER_
#define _SERIAL_USER_


#include "serial.h"

#define ESCAPE_CHAR 0xAA


extern uint8_t processPacket;


// prototypes

uint8_t ProcessReceiveBuffer(void);

uint8_t ProcessPacket(void);

#endif