// ux_manager.c


#include "main.h"
#include "ux_manager.h"
#include <stdio.h>
#include "KeyboardHoldRepeat.h"

// private defines


// Global Constants


// Modular Constants


// global variables
// Screens
ui_screen currentScreen;
ui_screen lastScreen;

// Display-wrapped values
// format seq (numeric): {<format string>, <error message>, <Xpos>, <Ypos>, <valid?>, <init value>}
DWfloat counter = {"%5.2f", "----", 0, 0, true, 0};
DWfloat tempInF = {"%4.1f", "----", 0, 0, true, 72.2};
DWfloat humidity = {"%4.1f", "----", 0, 0, true, 40.1};
DWint16_t tempCJ_F = {"%5d", "!!!!", 0, 0, true, 0};
DWfloat Target = {"%4.1f", "----", 0, 0, true, 72.2};

DWuint16_t adcTherm = {"%3X", "----",0 ,0, true, 0};
DWuint16_t adcTC = {"%3X", "----",0 ,0, true, 0};
DWuint16_t adcPOT = {"%3X", "----",0 ,0, true, 0};
DWuint16_t adcTcOffset = {"%3X", "----",0 ,0, true, 0};
DWuint8_t keyTest = {"0x%02X", "----",0 ,0, true, 0};
DWstring Meat = {"%s", "----",0 ,0, true, ""};
DWstring Doneness = {"%s", "----",0 ,0, true, ""};
//int i = 0;
//int j = 0;
extern uint8_t meats[][20];
extern uint8_t kbdTest;


// format seq (string): {<format string>,  <error message>, <Xpos>, <Ypos>, <valid?>, "<init value>"


// modular variables


// module prototypes



// ***************
// Start Of Code
// ***************
// Screen switching utility that manages pre-, post-, and screen switch conditions

/*Needed screens: 1. Main screen: shows current temperature and doneness. 2. "Set temperature" screen. 2b. "Choose a meat" screen. 2c. "Choose meat doneness" screen. Both 2b and 2c comprise screen 2. We could also add a separate screen to manually input a temperature. 3. Cook screen. Shows current temp and target temp. Alarm beeps once temps converge.*/
void SwitchScreens(ui_screen screen_no)
{
  lastScreen = currentScreen;

  
#pragma diag_suppress= Pa149
  // what must be done before current screen is switched out
  switch (lastScreen) {
  }
  
  
  // what must be done before screen is switched in
  switch (screen_no) {
  }
#pragma diag_warning= Pa149
  
  // Switch the screens
  switch (screen_no) {
  case MAIN:
    // clear the screen from the previos dispayed data
    SSD1306_Clear();
    // Put up the "persistant" info (like data labels)
    SSD1306_GotoXY (0,0);
    SSD1306_Puts ("Meat Info", &Font_11x18, SSD1306_COLOR_WHITE);
    SSD1306_GotoXY (0, 20);
    SSD1306_Puts ("Temp:", &Font_11x18, SSD1306_COLOR_WHITE);
    // Set u X/Y coordinates for "live" data to be displayed on this screen
    tempInF.xPos = 55;
    tempInF.yPos = 20;
    SSD1306_GotoXY (0, 40);
    SSD1306_Puts ("Doneness:", &Font_7x10, SSD1306_COLOR_WHITE);
    Doneness.xPos = 60;
    Doneness.yPos = 40;
    break;
  case SET_TEMP_TH:
    SSD1306_Clear();
    SSD1306_GotoXY (0,0);
    SSD1306_Puts ("Choose meat", &Font_11x18, SSD1306_COLOR_WHITE);
    SSD1306_GotoXY (0, 20);
    SSD1306_Puts ("Meat: ", &Font_11x18, SSD1306_COLOR_WHITE);
    SSD1306_GotoXY (0, 50);
    SSD1306_Puts ("Doneness:", &Font_7x10, SSD1306_COLOR_WHITE);
    Meat.xPos = 55;
    Meat.yPos = 20;
    Doneness.xPos = 60;
    Doneness.yPos = 50;
    break;
  case SHOW_TEMP:
        SSD1306_Clear();
    SSD1306_GotoXY (0,0);
    SSD1306_Puts ("Temperature", &Font_11x18, SSD1306_COLOR_WHITE);
    SSD1306_GotoXY (0, 20);
    SSD1306_Puts ("Current:", &Font_7x10, SSD1306_COLOR_WHITE);
    SSD1306_GotoXY (0, 50);
    SSD1306_Puts ("Target:", &Font_7x10, SSD1306_COLOR_WHITE);
    tempInF.xPos = 55;
    tempInF.yPos = 20;
    Target.xPos = 60;
    Target.yPos = 50;
    break;
  case KBD_TEST:
    SSD1306_Clear();
    SSD1306_GotoXY (0,0);
    SSD1306_Puts ("KBD_TEST", &Font_11x18, SSD1306_COLOR_WHITE);
    SSD1306_GotoXY (0, 20);
    SSD1306_Puts ("kCode: ", &Font_11x18, SSD1306_COLOR_WHITE);
    keyTest.xPos = 70;
    keyTest.yPos = 20;
    break;
  case ADC_TEST:
    SSD1306_Clear();
    SSD1306_GotoXY (0,0);
    SSD1306_Puts ("ADC Test", &Font_11x18, SSD1306_COLOR_WHITE);
    
    SSD1306_GotoXY (0, 20);
    SSD1306_Puts ("H:", &Font_11x18, SSD1306_COLOR_WHITE);
    adcTherm.xPos = 20;
    adcTherm.yPos = 20;

    SSD1306_GotoXY (64, 20);
    SSD1306_Puts ("P:", &Font_11x18, SSD1306_COLOR_WHITE);
    adcPOT.xPos = 84;
    adcPOT.yPos = 20;

    SSD1306_GotoXY (0, 40);
    SSD1306_Puts ("T:", &Font_11x18, SSD1306_COLOR_WHITE);
    adcTC.xPos = 20;
    adcTC.yPos = 40;

    SSD1306_GotoXY (64, 40);
    SSD1306_Puts ("O:", &Font_11x18, SSD1306_COLOR_WHITE);
    adcTcOffset.xPos = 84;
    adcTcOffset.yPos = 40;
    break;
  }
  
  SSD1306_UpdateScreen(); //display

  currentScreen = screen_no;
  
#pragma diag_suppress= Pa149
  // what must be done after screen is switched in
  switch (currentScreen) {
  }
#pragma diag_warning= Pa149
  
}


//// Keyboard Processor
//
//uint8_t ProcessKeyCode (uint16_t key_code)
//{
//  switch (key_code) {
//  case 0:
//    break;
//  case 1:
//    break;
//  case 2:
//    break;
//  case 3:
//    break;
//  }
//  
//  return true;
//}


// context sensitive keyboard processor
uint8_t ProcessKeyCodeInContext (uint16_t key_code)
{
  switch (currentScreen) { //THESE DO NOT WORK FOR EXTERNAL PCB BUTTONS!!!!!
  case  MAIN:
    switch (kbdTest) {
    case 0:
      SwitchScreens(SET_TEMP_TH);
      break;
    case 1:
      break;
    case 2:
      break;
    case 3:
      break;
    }
    break;
  case  SET_TEMP_TH:
    switch (kbdTest) {
    case 0:
      SwitchScreens(SHOW_TEMP);
      break;
    case 1:
      //i++;
      //sprintf(Meat.data, "%s", meats[i]);
      //strcpy(Meat.data, meats[i]);
      break;
    case 2:
      //choose doneness
      break;
    case 3:
      break;
    }
    break;
  case  SHOW_TEMP:
    switch (kbdTest) {
    case 0:
      //SwitchScreens(SET_TEMP_TH);
      break;
    case 1:
      break;
    case 2:
      break;
    case 3:
      break;
    }
    break;
  case  SET_TEMP:
    switch (kbdTest) {
    case 0:
      break;
    case 1:
      break;
    case 2:
      break;
    case 3:
      break;
    }
    break;
  case  SET_HUM:
    switch (kbdTest) {
    case 0:
      break;
    case 1:
      break;
    case 2:
      break;
    case 3:
      break;
    }
    break;
  case  SET_TIME:   
    switch (kbdTest) {
    case 0:
      break;
    case 1:
      break;
    case 2:
      break;
    case 3:
      break;
    }
    break;
  }
  
  return true;
}




void UpdateScreenValues(void)
{
  char displayString[25];
  
  switch (currentScreen) {
  case MAIN:
    SSD1306_GotoXY (tempInF.xPos, tempInF.yPos);
    if (tempInF.valid) {
      sprintf(displayString, tempInF.format, tempInF.data);
      SSD1306_Puts(displayString, &Font_11x18, SSD1306_COLOR_WHITE);
    }
    else 
      SSD1306_Puts(tempInF.invalidMsg, &Font_11x18, SSD1306_COLOR_WHITE);
    SSD1306_GotoXY (Doneness.xPos, Doneness.yPos);
    if (Doneness.valid) {
      memset(&displayString, 0, 25);
      sprintf(displayString, Doneness.format, Doneness.data);
      SSD1306_Puts(displayString, &Font_7x10, SSD1306_COLOR_WHITE);
    }
    else 
      memset(&displayString, 0, 25);
      SSD1306_Puts(Doneness.invalidMsg, &Font_7x10, SSD1306_COLOR_WHITE);
    break;
  case SET_TEMP_TH:
    SSD1306_GotoXY (Meat.xPos, Meat.yPos);
    if (Meat.valid) {
      memset(&displayString, 0, 25);
      sprintf(displayString, Meat.format, Meat.data);
      SSD1306_Puts(displayString, &Font_11x18, SSD1306_COLOR_WHITE);
    }
    else
    {
      memset(&displayString, 0, 25);
      SSD1306_Puts(Meat.invalidMsg, &Font_11x18, SSD1306_COLOR_WHITE);
    }
    SSD1306_GotoXY (Doneness.xPos, Doneness.yPos);
    if (Doneness.valid) {
      memset(&displayString, 0, 25);
      sprintf(displayString, Doneness.format, Doneness.data);
      SSD1306_Puts(displayString, &Font_7x10, SSD1306_COLOR_WHITE);
    }
    else 
      memset(&displayString, 0, 25);
      SSD1306_Puts(Doneness.invalidMsg, &Font_7x10, SSD1306_COLOR_WHITE);
    break;
  case SHOW_TEMP:
    SSD1306_GotoXY (tempInF.xPos, tempInF.yPos);
    if (tempInF.valid) {
      sprintf(displayString, tempInF.format, tempInF.data);
      SSD1306_Puts(displayString, &Font_7x10, SSD1306_COLOR_WHITE);
    }
    else 
      SSD1306_Puts(tempInF.invalidMsg, &Font_7x10, SSD1306_COLOR_WHITE);
    
    SSD1306_GotoXY (Target.xPos, Target.yPos);
    if (Target.valid) {
      sprintf(displayString, Target.format, Target.data);
      SSD1306_Puts(displayString, &Font_7x10, SSD1306_COLOR_WHITE);
    }
    else
      SSD1306_Puts(Target.invalidMsg, &Font_7x10, SSD1306_COLOR_WHITE);
    break;
  case SHOW_HUM:
    break;
  case SET_TEMP:
    break;
  case SET_HUM:
    break;
  case SET_TIME:
    break;
  case KBD_TEST:
    SSD1306_GotoXY (keyTest.xPos, keyTest.yPos);
    if (keyTest.valid) {
      sprintf(displayString, keyTest.format, keyTest.data);
      SSD1306_Puts(displayString, &Font_11x18, SSD1306_COLOR_WHITE);
    }
    else 
      SSD1306_Puts(keyTest.invalidMsg, &Font_11x18, SSD1306_COLOR_WHITE);
    break;
  case ADC_TEST:
    // TC Offset
    SSD1306_GotoXY (adcTcOffset.xPos, adcTcOffset.yPos);
    if (adcTcOffset.valid) {
      sprintf(displayString, adcTcOffset.format, adcTcOffset.data);
      SSD1306_Puts(displayString, &Font_11x18, SSD1306_COLOR_WHITE);
    }
    else 
      SSD1306_Puts(adcTcOffset.invalidMsg, &Font_11x18, SSD1306_COLOR_WHITE);

    // TC
    SSD1306_GotoXY (adcTC.xPos, adcTC.yPos);
    if (adcTC.valid) {
      sprintf(displayString, adcTC.format, adcTC.data);
      SSD1306_Puts(displayString, &Font_11x18, SSD1306_COLOR_WHITE);
    }
    else 
      SSD1306_Puts(adcTC.invalidMsg, &Font_11x18, SSD1306_COLOR_WHITE);

    // POT
    SSD1306_GotoXY (adcPOT.xPos, adcPOT.yPos);
    if (adcPOT.valid) {
      sprintf(displayString, adcPOT.format, adcPOT.data);
      SSD1306_Puts(displayString, &Font_11x18, SSD1306_COLOR_WHITE);
    }
    else 
      SSD1306_Puts(adcPOT.invalidMsg, &Font_11x18, SSD1306_COLOR_WHITE);

    // Therm
    SSD1306_GotoXY (adcTherm.xPos, adcTherm.yPos);
    if (adcTherm.valid) {
      sprintf(displayString, adcTherm.format, adcTherm.data);
      SSD1306_Puts(displayString, &Font_11x18, SSD1306_COLOR_WHITE);
    }
    else 
      SSD1306_Puts(adcTherm.invalidMsg, &Font_11x18, SSD1306_COLOR_WHITE);
    break;    
  }
  SSD1306_UpdateScreen(); //display
}



uint8_t GetKeycode(void)
{
  return HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13);
}