/***********************************************************************************************************************
* File Name    : KeyboardHoldRepeat.c
* Version      : 
* Device(s)    : Keyboard Handler code
* Tool-Chain   : IAR Systems ARM
* Description  : This file implements support code for a keyCode that is a result of a keyboard or button scan
*              : 
* Creation Date: 10OCT2021
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "main.h"
#include "KeyboardHoldRepeat.h"
#include <stdio.h>
#include <string.h>
#include <stdint.h>

#include "ux_manager.h"



/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/


/***********************************************************************************************************************
Global/module variables
***********************************************************************************************************************/
extern uint8_t processKeyCode;
extern uint8_t keyCodeProcessed;

extern UART_HandleTypeDef huart1;


extern uint8_t beepActive;
extern uint8_t beepDisabled;

extern DWuint8_t Meat;
extern DWuint8_t Doneness;
extern uint8_t meats[][20];
extern uint8_t doneness[][20];

volatile uint8_t kbdTest = 0;
char testChar[1] = {'!'};
int i = 0;
int j = 0;

 


/***********************************************************************************************************************
module function prototypes
***********************************************************************************************************************/



/***********************************************************************************************************************
code start
***********************************************************************************************************************/
void ProcessKeyCode(uint8_t _kcode)
{
  //kbdTest = 27;
  //sprintf(&Meat.data, "%s", meats[0]);
  
  switch (_kcode) {
  case 0x0B:  // single keys:   1
    kbdTest = 1;
    HAL_UART_Transmit(&huart1,(uint8_t*)testChar, 1, 1000);
    if (++testChar[0] > '}') testChar[0] = '!';
    
    if (currentScreen == MAIN) {
        SwitchScreens(SET_TEMP_TH);
    }
    else if (currentScreen == SET_TEMP_TH){
      SwitchScreens(SHOW_TEMP);
    }
    else if (currentScreen == SHOW_TEMP){
      SwitchScreens(MAIN);
    }
      
    break;
  case 0x0D:  //                2
    kbdTest = 2;
    if (currentScreen == SET_TEMP_TH)
    {
      if (i == 4)
        i = 0;
      else
        i++;
      memset(&Meat.data, 0, 26);
      sprintf(&Meat.data, "%s", meats[i]); //Words with less than 6 letters seem to append a 7 at the end, for some reason
    }
    break;
  case 0x07:  //                3
    if (currentScreen == SET_TEMP_TH)
    {
      if(strcmp(&Meat.data, "Beef") == 0)
      {
        if (j > 5)
          j = 0;
        else
          j++;
      }
      
      if(strcmp(&Meat.data, "Fish") == 0)
      {
        if (j >= 5)
          j = 3;
        else if (j == 0 || j == 1 || j == 2)
          j = 3;
        else
          j++;
      }
      
      if(strcmp(&Meat.data, "Trky") == 0)
      {
        j = 5;
      }
      
      if(strcmp(&Meat.data, "Pork") == 0)
      {
        if (j >= 5)
          j = 2;
        else if (j == 0 || j == 1)
          j = 2;
        else
          j++;
      }
      
      if(strcmp(&Meat.data, "Crab") == 0)
      {
        if (j >= 5)
          j = 2;
        else if (j == 0 || j == 1)
          j = 2;
        else
          j++;
      }
      if (j > 5)
        j = 0;
      memset(&Doneness.data, 0, 26);
      sprintf(&Doneness.data, "%s", doneness[j]);
    }
    kbdTest = 37;
    break;
  case 0x0E:  //                4
    kbdTest = 22;
    //beepDisabled = false;
    //beepActive = true;
    break;
  case 0x0A:  // 2-key chords:  1+4
    kbdTest = 4;
//    SwitchScreens(ADC_Test);
    break;
  default:
    break;
  }
  
 
  processKeyCode = false;
  keyCodeProcessed = true;
  
}



uint8_t ValidKeyCode(uint8_t _kcode)
{
  uint8_t validKeyCode = false;
  
//  switch (_kcode) {
//  case 0x06:  // single keys:   1
//  case 0x05:  //                2
//  case 0x03:  //                3
//  case 0x02:  // 2-key chords:  1+3
//    validKeyCode = true;
//    break;
//  default:
//    break;
//  }

  switch (_kcode) {
  case 0x0B:  // single keys:   1
  case 0x0D:  //                2
  case 0x07:  //                3
  case 0x0E:  //                3
  case 0x0A:  // 2-key chords:  1+4
    validKeyCode = true;
    break;
  default:
    break;
  }
  return validKeyCode;
}


uint8_t ScanKeyboard(void)
{
  uint8_t keyCode = NO_KEY_PRESSED;
  
//  keyCode = (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_8) << 2) | (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_9) << 1) | (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13) << 0);
//  
//  if (keyCode != NO_KEY_PRESSED) {
//    switch (keyCode) {
//    case 6:
//      keyCode = 0;
//      break;
//    case 5:
//      keyCode = 1;
//      break;
//    case 3:
//      keyCode = 2;
//      break;
//    case 2:
//      keyCode = 3;
//      break;
//    }      
//  }

  keyCode = (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_0) << 3) |
            (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_5) << 2) |
            (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_8) << 1) |
            (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_10) << 0);

  
  keyTest.data = keyCode;
  return keyCode;
}
